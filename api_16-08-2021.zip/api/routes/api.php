<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::middleware('api')->post('/register', 'AuthController@register');
Route::middleware('api')->post('/login', 'AuthController@login');
Route::middleware('api')->get('/rooms/list/{qty}', 'RoomController@getRooms');
Route::middleware('api')->get('/activites/list/{lesson_id}', 'ActivityController@getActivities');
Route::middleware('api')->get('/lesson/list/{room_id}', 'LessonController@getLessons');
Route::middleware('api')->get('/activity/detail/{activity_id}', 'ActivityController@getActivityDetail');
Route::middleware('api')->post('/points/set', 'UserActivityPointsController@setActivityPoints');


Route::get('/forbidden', function()
{
	return response()->json([
	    'status' => 'error',
	    'message' => 'You are not authorized to access requested data',
	]);
});