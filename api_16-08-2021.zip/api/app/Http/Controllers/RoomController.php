<?php

namespace App\Http\Controllers;

use App\Models\room;
use Illuminate\Http\Request;
use App\Models\RoomModel;

class RoomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct(RoomModel $room)
    {
        $this->room = $room;
        $this->middleware('auth:api',['except' => ['/api/forbidden']]);
    }

    public function getRooms($qty = 10)
    {
        if($qty > 0)
        {
            return $this->room->take($qty)->select('name')->get();    
        }
        else
        {
         return response()->json(['status'=>'error', 'message' => 'Requested Quantity must be greater then zero.']);   
        }
        
        //return $this->room->join('units','rooms.unitID','=','units.id')->select('rooms.name as roomName','units.name as unitName')->get();
    }
}
