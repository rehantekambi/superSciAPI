<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ValidateAuthGenerateRequest ;
use App\Models\clientAuthKey;
use App\Models\client;
use Illuminate\Support\Str;

class ClientAuthKeyController extends Controller
{
  
  
	public function __construct(clientAuthKey $clientAuthKey,client $client )
	{	    
	  $this->client = $client;
	 	$this->clientAuthKey = $clientAuthKey;  
	}
    public function createAuthCreds(ValidateAuthGenerateRequest $request)
    {
    	   try{

       		$client = $this->client->create($request->validated());
       		$secret_raw = Str::random(30);
	        $api_sec = join('-', str_split($secret_raw, 6));

	        $api_raw =  Str::uuid();
	        $api_key = $this->validateApiKey($api_raw);
       		$clientAuthKey = $this->clientAuthKey->create([
			    'client_id' => $client->id,
			    'key' => $api_key,
			    'secret' => $api_sec,
			    'status' => 1,
    			]);
           		return response()->json(['status'=>'Success', 'message' => 'Client Auth Secret and API Generated successfully.','key'=>$clientAuthKey->key,'secret'=>$clientAuthKey->secret]);
           		//if token needed on registration then use commented code line below
           		 //return $this->login($request);
    	    }catch(\Exception $e){
    	        return $e->getMessage();
    	    }
    }
    public function validateApiKey($key){

        $credentials = $this->clientAuthKey::where('key',$key)->first();
        if (!$credentials){
            return $key;
        }else{
            $key =  Str::uuid();
            return $key;
        }

    }
}
