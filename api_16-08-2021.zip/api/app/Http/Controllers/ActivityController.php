<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ActivityModel;

class ActivityController extends Controller
{
	public function __construct(ActivityModel $activity)
    {
        $this->activity = $activity;
        $this->middleware('auth:api');
    }
    public function getActivities($lessonID=1)
    {
    	//return $this->activity->where('lessonID',$lessonID)->where('status','1')->get();
    	return $this->activity->join('lessons','activities.lesson_id','=','lessons.id')->select('lessons.name as lessonName','activities.name as activityName','description','points_upon_completion')->get();
    }
    public function getActivityDetail($activityID)
    {

        //We have heirarchy like Activity->Questions->Answers. So we use three level of relationship to get answers from activities by using '.' with grand children
    	$activityDetail =  $this->activity
        ->with(['questions' => function($query) {
                    return $query->select('id', 'question', 'activity_id');
                }])
        ->with(['questions.answers' => function($query) {
                    return $query->select('id', 'question_id', 'answer_text','is_right');
                }])
        ->where('id',$activityID)->where('status','1')->get();
        
        $json_prepared = '{';
        if(isset($activityDetail[0]))
        {
            foreach($activityDetail AS $each_activity)
            {
               
                $json_prepared .= "'id':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'name':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'description':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'points_upon_completion':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'lesson_id':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'css_class':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'activity_type_class':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'starting_animation_video':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'ending_animation':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'starting_background':'".$each_activity['points_upon_completion']."',";
                $json_prepared .= "'ending_background':'".$each_activity['points_upon_completion']."',";

                $questions_for_json = '{';
                if($each_activity['questions'])
                {
                    foreach($each_activity['questions'] as $each_question )
                    {
                        $questions_for_json .= "'id':'".$each_question['id']."','question':'".$each_question['question']."',";
                        $answers_for_json = '{';
                        if($each_question['answers'])
                        {
                            foreach($each_question['answers'] as $each_answer )
                            {
                                $answers_for_json .= "'id':'".$each_answer['id']."','answer':'".$each_answer['answer_text']."','is_right':'".$each_answer['is_right']."'";
                            }
                        }
                        $answers_for_json .= '},';
                         $questions_for_json .= "'Answers':".$answers_for_json;
                    }
                }
                $questions_for_json .= "},";
            }
            $json_prepared .= "'Questions':".$questions_for_json." } ";

            return json_encode($json_prepared);
        }
        else
        {
               return response()->json(['status'=>'error', 'message' => 'Activity Not available']);             
        }
    }
}
