<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LessonModel extends Model
{
    use HasFactory;
    protected $table = 'lessons';
    protected $fillable = ['id','name','room_id'];

    public function rooms()
    {
        return $this->belongsTo(RoomsModel::class,'room_id');
    }

    public function activities()
    {
        return $this->hasMany(activitiesModel::class,'lesson_id');
    }
}
