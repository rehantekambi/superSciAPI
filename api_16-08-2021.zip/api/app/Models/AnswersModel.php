<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AnswersModel extends Model
{
    use HasFactory;

    protected $table = 'answers';
    protected $fillable = ['id','question_id','answer_text','is_right'];

    public function question()
    {
        return $this->belongsTo(QuestionsModel::class,'question_id');
    }

}
