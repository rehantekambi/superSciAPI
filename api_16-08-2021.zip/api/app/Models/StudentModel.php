<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentModel extends Model
{
    use HasFactory;
     protected $table = 'students';
     protected $fillable = ['id','user_id','dob','current_grade_level','class_id','points'];
}
