<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use App\Exceptions\InvalidOrderException;
use Symfony\Component\Routing\Exception\RouteNotFoundException;


class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     *
     * @return void
     */
 public function register()
{
    //exception handling by dependibot for specially 405 and 404
    $this->renderable(function (MethodNotAllowedHttpException $e, $request) {
        return response()->json([
            'status' => 'error',
            'message' => 'Request Method not Allowed',
        ]);
    });

    $this->renderable(function (NotFoundHttpException $e, $request) {
        return response()->json([
            'status' => 'error',
            'message' => 'Requested page not found on server or moved.',
        ]);
    });
    
    $this->renderable(function (RouteNotFoundException $e, $request) {
        return response()->json([
            'status' => 'error',
            'message' => 'Your Authorization is missing or Route is not defined.',
        ]);
    });
}


   
}
