<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\gradeLevel;
class gradeLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
		    ['id'=>0,'name'=>'Kindergarten'],
		    ['id'=>1,'name'=>'First Grade'],
		    ['id'=>2,'name'=>'Second Grade'],
		    ['id'=>3,'name'=>'Third Grade'],
		    ['id'=>4,'name'=>'Fourth Grade'],
		    ['id'=>5,'name'=>'Fifth Grade'],
		    ['id'=>6,'name'=>'Sixth Grade'],
		    ['id'=>7,'name'=>'Seventh Grade'],
		    ['id'=>8,'name'=>'Eighth Grade'],
		    ['id'=>9,'name'=>'Ninth Grade'],
		    ['id'=>10,'name'=>'Tenth Grade'],
		    ['id'=>11,'name'=>'Eleventh Grade'],
		    ['id'=>12,'name'=>'Twelfth Grade'],

		];

		gradeLevel::insert($data);
		
    }
}
