<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\privilege;
class privilegesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$data = [
		    ['privilege_level'=>'Master'],
		    ['privilege_level'=>'District'],
		    ['privilege_level'=>'School'],
		    ['privilege_level'=>'Class']
		];

		privilege::insert($data);
    }
}
