<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RemoveTypeAndAnswerColumnFromQuestions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
           Schema::table('questions', function($table) {
             $table->dropColumn('type');
             $table->dropColumn('answer');
          });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::table('questions', function($table) {
             $table->integer('type')->after('name');
             $table->integer('answer')->after('question');
          });
    }
}
