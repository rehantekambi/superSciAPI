<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddActivityDetailColumnsInActivities extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->enum('activity_type_class', ['key-science-lingo', 'assessment', 'free-exploration','puzzle'])->default('Key Science Lingo')->after('css_class');
            $table->string('starting_animation_video')->after('activity_type_class');
            $table->string('ending_animation')->after('starting_animation_video');
            $table->string('starting_background')->after('ending_animation');
            $table->string('ending_background')->after('starting_background');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropColumn('activity_type_class');
            $table->dropColumn('starting_animation_video');
            $table->dropColumn('ending_animation');
            $table->dropColumn('starting_background');
            $table->dropColumn('ending_background');
        });
    }
}
