<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\clientAuthKey;
use App\Models\client;
use App\Models\ActivityModel;
use App\Models\RoomModel;
use App\Models\LessonModel;

class ActivityDetailApiTest extends TestCase
{
    private $api_endpoint_without_param = 'api/activity/detail/';
    //last parameter is activity ID
    private $api_endpoint = 'api/activity/detail/2147483647';
    public function setUp() : void
    {
        parent::setUp();
    }
    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);
        User::where('email','SampleTesting@sampling.com')->delete();
        client::where('name','sampleClientName')->delete();
        ActivityModel::where('id','2147483647')->delete();  
        LessonModel::where('id','2147483647')->delete();
        RoomModel::where('id','2147483647')->delete();
    }

    public function testApiEndPointShouldReturnStatus200WhenAccess()
    {
        $response = $this->get($this->api_endpoint);
        $response->assertStatus(200);
    }

    public function testApiSuccessResponseShouldHaveKeyName()
    {
        $fakeActivity = $this->createFakeActivity();
        $auth_generator = $this->AuthTokenGenerator();
        $response = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token'] ])->json();
        $this->assertArrayHasKey('points_upon_completion',$response[0]);
    }

    public function testApiSuccessResponseShouldReturnEmptyIfRecordNotAvailable()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response = $this->call('GET',$this->api_endpoint_without_param.'2147483647', [], [],[], ['HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token'] ]);

       $response->assertJson([
                'message' => 'Activity Not available',
            ]);
    }

    public function testEndPointWillReturnErrorWithWrongHeaderSecret()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response2 = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => 'abc',
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token']]);

        $response2->assertJson([
                'status' => 'error',
            ]);
    }

    public function testEndPointWillReturnErrorWithWrongHeaderKey()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response3 = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => 'abc',
            'Authorization' => 'bearer '.$auth_generator['token']]);

        $response3->assertJson([
                'status' => 'error',
            ]);
    }
}
