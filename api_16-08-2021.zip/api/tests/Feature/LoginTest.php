<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\clientAuthKey;
use App\Models\client;
use App\Models\TeacherModel;
use App\Models\ClassesModel;
use App\Models\SchoolModel;
use App\Models\DistrictModel;
use App\Models\ScienceStandardModel;
use App\Models\StatesModel;
use App\Models\StudentModel;
use Illuminate\Support\Str;

class LoginTest extends TestCase
{
    public function setUp() : void
    {
        parent::setUp();
       
    }

    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);
        TeacherModel::where('class_id','2147483647')->delete();
        StudentModel::where('class_id','2147483647')->delete();
        User::where('email','sampletesting@sampling.com')->delete();
        client::where('name','sampleClientName')->delete();
        ClassesModel::where('id','2147483647')->delete();
        SchoolModel::where('id','2147483647')->delete();
        DistrictModel::where('id','2147483647')->delete();        
        StatesModel::where('id','XYZ')->delete();
        ScienceStandardModel::where('id','2147483647')->delete();
    }

    public function testLoginShouldReturnSuccessWithCorrectCredentials()
    {      
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertJson([
                'status' => 'success',
            ]);
    }

    public function testLoginShouldShowErrorWhenEmailIsEmpty()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => '',
            'password' => '123456',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertSessionHasErrors(['email'=>'You must enter email to proceed.']);
    }

    public function testLoginShouldShowErrorWhenPasswordIsEmtpy()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sample@gm.com',
            'password' => '',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertSessionHasErrors(['password'=>'You must enter password to proceed.']);
    }

    public function testLoginShouldShowErrorWhenEmailFormatIsWrong()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sample',
            'password' => '123456789',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);
       
        $response->assertSessionHasErrors(["email"=>"The email must be a valid email address."]);
    }

   public function testLoginShouldReturnErrorWithInvalidCredentials()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'abcdef'
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertJson([
                'status' => 'error',
           ]);
    }

    public function testLoginShouldShowErrorWhenBothFieldsAreEmpty()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => '',
            'password' => '',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertSessionHasErrors(['email'=>'You must enter email to proceed.', 'password'=>'You must enter password to proceed.']);
    }

    public function testTeacherLoginShouldReturnTypeTeacher()
    {
        $creds = $this->AuthTokenGenerator();
        $fake_edu_flow =  $this->createFakeEducationFlow();
        $teacherCreate =  TeacherModel::create([
           'user_id' => $creds['userID'], 
           'class_id' =>  $fake_edu_flow['class_id'],  
        ]);
        $response = $this->call('POST', '/api/login', [
            'email' => 'SampleTesting@sampling.com',
            'password' => 'sample123',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);
        
        $response->assertJsonFragment([
                'type' => 'teacher',
        ]);
    }

    public function testStudentLoginShouldReturnTypeStudent()
    {
        $creds = $this->AuthTokenGenerator();
        $fake_edu_flow =  $this->createFakeEducationFlow();
        $studentCreate =  StudentModel::create([
           'user_id' => $creds['userID'], 
           'dob' => '2021-06-10', 
           'current_grade_level' => '1', //1 grade level for first grade 
           'class_id' => $fake_edu_flow['class_id'], 
           'points' => '20', 
        ]);
        $response = $this->call('POST', '/api/login', [
            'email' => 'SampleTesting@sampling.com',
            'password' => 'sample123',
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);
        
        $response->assertJsonFragment([
                'type' => 'student',
            ]);
    }
    public function testLoginShouldReturnErrorWhenEmailCorrectWithWrongPassword()
    {      
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'abcdef'
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

        $response->assertJson([
                'status' => 'error',
            ]);
    }
}
