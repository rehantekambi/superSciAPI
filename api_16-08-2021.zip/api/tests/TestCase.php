<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use App\Models\ClassesModel;
use App\Models\SchoolModel;
use App\Models\DistrictModel;
use App\Models\ScienceStandardModel;
use App\Models\StatesModel;
use App\Models\RoomModel;
use App\Models\LessonModel;
use App\Models\ActivityModel;
abstract class TestCase extends BaseTestCase
{
    use CreatesApplication;

     public function AuthTokenGenerator()
    {
        $ClientAuth = $this->call('POST', '/generateClientAuth', [
            'name' => 'sampleClientName',
            'type' => 'testing',
        ]);
        $RegTestUser = $this->call('POST', '/api/register', [
            'id' => '2147483647',
            'first_name' => 'SampleFname',
            'last_name' => 'SampleLname',
            'email' => 'SampleTesting@sampling.com',
            'password' => 'sample123',
            'privilege_id' => '1',
        ], [],[], ['HTTP_key' => $ClientAuth['key'],'HTTP_secret' => $ClientAuth['secret'],'HTTP_Accept' => 'application/json', ]);

        $GetTokenForTestUser = $this->call('POST', 'api/login', [
            'email' => 'SampleTesting@sampling.com',
            'password' => 'sample123',
        ], [],[], 
        ['HTTP_key' => $ClientAuth['key'],
        'HTTP_secret' => $ClientAuth['secret'],
        'HTTP_Accept' => 'application/json' ]);
        return array('key'=>$ClientAuth['key'],'secret'=>$ClientAuth['secret'],'token'=>$GetTokenForTestUser['access_token'],'userID'=>$RegTestUser['userID']);
    }
    public function createFakeClientWithKey()
    {
        $ClientAuth = $this->call('POST', '/generateClientAuth', [
            'name' => 'sampleClientName',
            'type' => 'testing',
        ]);
        return array('key'=>$ClientAuth['key'],'secret'=>$ClientAuth['secret']);
    }
    public function createFakeEducationFlow()
    {
        $scienceStandardCreate =  ScienceStandardModel::create([
            'id' => '2147483647',
           'name' => 'SampleScienceStandardTest', 
        ]); 
        $stateCreate = StatesModel::create([
            'id' => 'XYZ',
            'science_standard_id' => $scienceStandardCreate->id,
        ]);
        $districtCreate =  DistrictModel::create([
           'id' => '2147483647',
           'name' => 'SampleDistrictTest',
           'state_abbreviation' => 'XYZ', 
        ]); 
        $schoolCreate =  SchoolModel::create([
            'id' => '2147483647', 
           'name' => 'SampleSchoolNameTest', 
           'district_id' => $districtCreate->id, 
        ]); 
        $classCreate =  ClassesModel::create([
            'id' => '2147483647', 
           'name' => 'SampleClassNameTest', 
           'school_id' => $schoolCreate->id, 
           'grade_level_id' => 1, //for first grade
        ]); 

        return array('science_standard_id'=>$scienceStandardCreate->id,
                    'state_id'=>$stateCreate->id,
                    'district_id'=>$districtCreate->id,
                    'school_id'=>$schoolCreate->id,
                    'class_id'=>$classCreate->id);
    }
    public function createFakeLesson()
    {
        $fakeRoom = $this->createFakeRoom();
        $lessonCreate =  LessonModel::create([
            'id' => '2147483647', 
           'name' => 'SampleLessonNameTest', 
           'room_id' => $fakeRoom['room_id'], 
        ]); 
        return array('room_id'=>$fakeRoom['room_id'],
                    'lesson_id'=>$lessonCreate->id);
    }
    public function createFakeRoom()
    {
        $roomCreate =  RoomModel::create([
            'id' => '2147483647', 
           'name' => 'sampleRoomNameTest', 
           'css_class' => 'abc', 
        ]); 
         return array('room_id'=>$roomCreate->id);
    }
    public function createFakeActivity()
    {
        $fakeLesson = $this->createFakeLesson();
        $createActivity = ActivityModel::create([
            'id' => '2147483647',
            'name' => 'SampleActivityDummyData',
            'description' => 'SampleActivityDummyData',
            'points_upon_completion' => '20',
            'lesson_id' => $fakeLesson['lesson_id'],
        ]);
        return array('activity_id'=>$createActivity->id,
                    'lesson_id'=>$fakeLesson['lesson_id']);
    }
}
