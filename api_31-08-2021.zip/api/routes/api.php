<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::middleware('api')->post('/register', 'AuthController@register');
Route::middleware('api')->post('/login', 'AuthController@login');
Route::middleware('api')->get('/rooms/list/{qty}', 'RoomController@getRooms')->where('qty', '[0-9]+');
Route::middleware('api')->get('/activites/list/{lesson_id}/{user_id?}', 'ActivityController@getActivities')->where('lesson_id', '[0-9]+')->where('user_id', '[0-9]+');
Route::middleware('api')->get('/lesson/list/{room_id}', 'LessonController@getLessons')->where('room_id', '[0-9]+');
Route::middleware('api')->get('/activity/detail/{activity_id}', 'ActivityController@getActivityDetail')->where('activity_id', '[0-9]+');
Route::middleware('api')->post('/points/set', 'UserActivityPointsController@setActivityPoints');
Route::middleware('api')->get('/points/get/{user_id}/{activity_id?}', 'UserActivityPointsController@getActivityPoints')->where('user_id', '[0-9]+')->where('activity_id', '[0-9]+');


Route::get('/forbidden', function()
{
	return response()->json([
	    'status' => 'error',
	    'message' => 'You are not authorized to access requested data',
	]);
});