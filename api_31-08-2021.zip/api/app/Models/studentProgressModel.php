<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class studentProgressModel extends Model
{
    use HasFactory;
    protected $table = 'students_progress';
    protected $fillable = ['id','activity_id','student_id','completed','points_earned','percentage_completion'];

    public function activity()
    {
        return $this->belongsTo(ActivityModel::class,'activity_id');
    }
}
