<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserActivityPointsModel extends Model
{
    use HasFactory;
    protected $table = 'user_activity_points';
    protected $fillable = [
        'activity_id','user_id','last_name','points', 'completion_time_in_sec','status'
    ];
}
