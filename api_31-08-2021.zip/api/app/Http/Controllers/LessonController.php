<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LessonModel;

class LessonController extends Controller
{
     public function __construct(LessonModel $lesson)
    {
        $this->lesson = $lesson;
        $this->middleware('auth:api');
    }

    public function getLessons($roomID)
    {
        try{
            $list =  $this->lesson->where('room_id',$roomID)->get(['id','name','description']);
            if(count($list) > 0)
            {
                return $list;
            } 
            else
            {
                return response()->json(['status'=>'Error', 'Message' => 'No Data Found against given Room ID.' ]);
            }
            
            
        }catch(\Exception $e){
                return response()->json(['status'=>'Error', 'message' => 'There is an error while getting your data. Please contact administrator.']);
        }
    }
}
