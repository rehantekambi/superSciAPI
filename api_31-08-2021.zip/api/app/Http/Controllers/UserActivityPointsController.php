<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserActivityPointsModel;
use App\Http\Requests\ValidateUserActivityScore ;

class UserActivityPointsController extends Controller
{
    public function __construct(UserActivityPointsModel $setpoints )
    {       
      $this->activityPoints = $setpoints;
      $this->middleware('api');
    }
    
    public function setActivityPoints(ValidateUserActivityScore $request)
    {
        try{
        //saving activity points : time must be in seconds
        $setting_points = $this->activityPoints->create($request->validated());
        return response()->json(['status'=>'Success', 'message' => 'User Activity points saved successfully.']);
        }catch(\Exception $e){
                return response()->json(['status'=>'Error', 'message' => 'There is an error while saving Activity points. Please contact your administrator.']);
        }
    }

    public function getActivityPoints($user_id,$activity_id = '')
    {
        try{
            if($activity_id > 0)
            {
                $points = $this->activityPoints->
                    where('status',1)->
                    where('activity_id',$activity_id)->
                    where('user_id',$user_id)->sum('points');
                    return response()->json(['status'=>'Success', 'Score' => $points , 'activity_id' => $activity_id, 'user_id' => $user_id ]); 
            }
            else
            {
                $points =  $this->activityPoints->
                    where('status',1)->
                    where('user_id',$user_id)
                    ->sum('points'); 
                return response()->json(['status'=>'Success', 'Score' => $points , 'user_id' => $user_id ]); 
            }
        }catch(\Exception $e){
                return response()->json(['status'=>'Error', 'message' => 'There is an error while saving Activity points. Please contact your administrator.']);
        }
    }
}
