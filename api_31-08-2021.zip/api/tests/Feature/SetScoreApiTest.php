<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\clientAuthKey;
use App\Models\client;
use App\Models\ActivityModel;
use App\Models\RoomModel;
use App\Models\LessonModel;

class SetScoreApiTest extends TestCase
{
    private $api_endpoint_without_param = 'api/points/set';
    public function setUp() : void
    {
        parent::setUp();
    }
    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);
        User::where('email','SampleTesting@sampling.com')->delete();
        client::where('name','sampleClientName')->delete();
        ActivityModel::where('id','2147483647')->delete();  
        LessonModel::where('id','2147483647')->delete();
        RoomModel::where('id','2147483647')->delete();
    }

    public function testApiEndPointShouldReturnStatus200WhenAccess()
    {
        $response = $this->get($this->api_endpoint);
        $response->assertStatus(200);
    }

    public function testApiSetPointsForActivityShouldReturnSuccess()
    {
        $fakeActivity = $this->createFakeActivity();
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', $this->api_endpoint, [
            'user_id' => 2147483647,
            'activity_id' => $fakeActivity['activity_id'],
            'points' => 20,
            'completion_time_in_sec' => 50,
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => $creds['secret'] ]);

         $response->assertJson([
                'status' => 'success',
            ]);
    }
}
