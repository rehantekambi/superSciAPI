<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Http\Controllers\ClientAuthKeyController;
use App\Models\User;
use App\Models\clientAuthKey;
use App\Models\client;
use App\Models\ActivityModel;
use App\Models\RoomModel;

class RoomsApiTest extends TestCase
{
    //last parameter will be qty of rooms request
    private $api_endpoint_without_param = '/api/rooms/list/';
    private $api_endpoint = '/api/rooms/list/5';

     public function setUp() : void
    {
        parent::setUp();
       // $this->createAuth = new ClientAuthKeyController();
       
    }
    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);
        User::where('email','SampleTesting@sampling.com')->delete();
        //clientAuthKey::where('client_id','')->delete();
        client::where('name','sampleClientName')->delete();
        RoomModel::where('id','2147483647')->delete();
    }
    /**
     * A basic feature test example.
     *
     * @return void
     */
    /** @test **/
    public function apiEndPointShouldShowOk200WhenAccess()
    {
        
        $response = $this->get($this->api_endpoint);
        $response->assertStatus(200);
    }
    /** @test **/
    public function apiSuccessResponseShouldHaveKeyNameInJsonFormat()
    {
        RoomModel::create([
            'id' => 2147483647,
            'name' => 'SampleRoomDummyData',
            'css_class' => 'abc'
           
        ]);
        $auth_generator = $this->AuthTokenGenerator();
        $response1 = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token'] ])->json();

        $this->assertArrayHasKey('name',$response1[0]);
        //$response->assertStatus(200);

    }
    /** @test **/
    public function endPointWillReturnErrorWithWrongHeaderSecret()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response2 = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => 'abc',
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token']]);
     //   dd($response);
        $response2->assertJson([
                'status' => 'error',
            ]);
        //$response->assertStatus(200);

    }
     /** @test **/
    public function endPointWillReturnErrorWithWrongHeaderKey()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response3 = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => 'abc',
            'Authorization' => 'bearer '.$auth_generator['token']]);
     //   dd($response);
        $response3->assertJson([
                'status' => 'error',
            ]);
        //$response->assertStatus(200);

    }
     /** @test **/
    public function endPointWillHaveQuantityGreaterThenZero()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response4 = $this->call('GET',$this->api_endpoint_without_param.'0', [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token']]);
    
        $response4->assertJson([
                'message' => 'Requested Quantity must be greater then zero.',
            ]);
        //$response->assertStatus(200);

    }
}
