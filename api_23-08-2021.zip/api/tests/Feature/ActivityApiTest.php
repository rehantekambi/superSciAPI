<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\clientAuthKey;
use App\Models\client;
use App\Models\ActivityModel;
use App\Models\RoomModel;
use App\Models\LessonModel;

class ActivityApiTest extends TestCase
{
    private $api_endpoint = 'api/activites/list/5';

    public function setUp() : void
    {
        parent::setUp();
        $fakeLessonAndRoom = $this->createFakeActivity();
    }
    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);
        ActivityModel::where('name','SampleActivityDummyData')->delete();
        User::where('email','SampleTesting@sampling.com')->delete();
        client::where('name','sampleClientName')->delete();
        ActivityModel::where('id','2147483647')->delete();
        LessonModel::where('id','2147483647')->delete();
        RoomModel::where('id','2147483647')->delete();
    }
    
    public function testApiEndPointShouldReturnStatus200WhenAccess()
    {
        $response = $this->get($this->api_endpoint);
        $response->assertStatus(200);
    }

    public function testApiSuccessResponseShouldHaveKeyActivityName()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token'] ])->json();
        $this->assertArrayHasKey('activityName',$response[0]);
    }

    public function testEndPointShouldReturnErrorWithWrongHeaderKey()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => 'abc',
            'HTTP_secret' => $auth_generator['secret'],
            'Authorization' => 'bearer '.$auth_generator['token']]);

        $response->assertJson([
                'status' => 'error',
        ]);
    }

    public function testEndPointWillReturnErrorWithWrongHeaderSecret()
    {
        $auth_generator = $this->AuthTokenGenerator();
        $response = $this->call('GET',$this->api_endpoint, [], [],[], [
            'HTTP_key' => $auth_generator['key'],
            'HTTP_secret' => 'abc',
            'Authorization' => 'bearer '.$auth_generator['token']]);

        $response->assertJson([
                'status' => 'error',
        ]);
    }
     
   
    
}
