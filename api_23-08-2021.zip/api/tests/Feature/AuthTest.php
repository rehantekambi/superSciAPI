<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\User;
use App\Models\client;
use Illuminate\Support\Str;

class AuthTest extends TestCase
{
    public function setUp() : void
    {
        parent::setUp();
       
    }

    public function tearDown() : void
    {
        $config = app('config');
        parent::tearDown();
        app()->instance('config', $config);  
        User::where('email','sampletesting@sampling.com')->delete();
        client::where('name','sampleClientName')->delete();
    }

    public function testLoginAuthShouldShowSuccessWhenKeyAndSecretAreCorrect()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => $creds['key'], 'HTTP_secret' => $creds['secret']]);

        $response->assertJson([
                'status' => 'success',
        ]);
    }

    public function testLoginAuthShouldShowErrorWhenHeaderKeyIsNotValid()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => 'InvalidAuthKey','HTTP_secret' => $creds['secret'] ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }
    public function testLoginAuthShouldShowErrorWhenHeaderSecretIsNotValid()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => $creds['key'],'HTTP_secret' => 'InvalidAuthSecret' ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }
    public function testLoginAuthShouldShowErrorWhenKeyAndSecretBothAreNotValid()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => 'InvalidAuthKey','HTTP_secret' => 'InvalidAuthSecret' ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }
    public function testLoginAuthShouldShowErrorWhenKeyAndSecretBothAreEmpty()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => '','HTTP_secret' => '' ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }
    public function testLoginAuthShouldShowErrorWhenKeyIsEmpty()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => '','HTTP_secret' => $creds['secret'] ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }
    public function testLoginAuthShouldShowErrorWhenSecretIsEmpty()
    {
        $creds = $this->AuthTokenGenerator();
        $response = $this->call('POST', '/api/login', [
            'email' => 'sampletesting@sampling.com',
            'password' => 'sample123'
        ], [],[], ['HTTP_key' => '',$creds['key'] => '' ]);

        $response->assertJson([
                'message' => 'You are not authorized to send request.',
            ]);
    }

}