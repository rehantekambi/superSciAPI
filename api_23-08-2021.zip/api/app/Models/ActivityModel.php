<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityModel extends Model
{
    use HasFactory;
     protected $table = 'activities';
     protected $fillable = ['id','name','description','points_upon_completion','lesson_id','css_class','activity_type_class','starting_animation_video','ending_animation','starting_background','ending_background'];
     

    public function lesson()
    {
        return $this->belongsTo(LessonModel::class,'lesson_id');
    }

    public function questions()
    {
        return $this->hasMany(QuestionsModel::class,'activity_id');
    }

    public function narrations()
    {
        return $this->hasMany(NarrationsModel::class,'activity_id');
    }

    public function DrAstroNarrations()
    {
        return $this->hasMany(NarrationsModel::class,'activity_id');
    }

    public function Narrations2b()
    {
        return $this->hasMany(NarrationsModel::class,'activity_id');
    }

    
}
