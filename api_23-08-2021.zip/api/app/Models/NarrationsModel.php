<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NarrationsModel extends Model
{
    use HasFactory;
    protected $table = 'activity_narrations';
    protected $fillable = ['id','activity_id','narration_text','sort_order','narration_type','status'];

    public function activity()
    {
        return $this->belongsTo(ActivityModel::class,'activity_id');
    }
}
