<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\clientAuthKey;

class RequestAuthenticationByKeySecret
{
    public function __construct(clientAuthKey $clientAuthKey )
    {       
        $this->clientAuthKey = $clientAuthKey;  
    }
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $attemptHeaderAuth = $this->clientAuthKey::where('key',$request->header('key'))->where('secret',$request->header('secret'))->first();

            if (!$attemptHeaderAuth){
                return response()->json(['status'=>'error', 'message' => 'You are not authorized to send request.']);
            }else{
               return $next($request);
            }  
    }
}
