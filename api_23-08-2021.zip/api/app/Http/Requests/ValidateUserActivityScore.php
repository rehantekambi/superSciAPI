<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ValidateUserActivityScore extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user_id' => 'required|integer',
            'activity_id' => 'required|integer',
            'points' => 'required|numeric',
            'completion_time_in_sec' => 'required|numeric',
        ];
    }
    public function messages()
    {
        return [
            'completion_time_in_sec.numeric' => 'Completion time must be in second.',
        ];
    }
}
