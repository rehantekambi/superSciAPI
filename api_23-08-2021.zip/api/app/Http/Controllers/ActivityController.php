<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ActivityModel;
use App\Models\NarrationsModel;
use DB;

class ActivityController extends Controller
{
	public function __construct(ActivityModel $activity)
    {
        $this->activity = $activity;
        $this->middleware('auth:api');
    }
    public function getActivities($lessonID)
    {
    	//return $this->activity->where('lessonID',$lessonID)->where('status','1')->get();
    	 $activityDetail = ($this->activity
            ->with(['lesson' => function($query) {
                    return $query->select('id', 'name as lessonName');
                }])
            ->where('status','1')->where('id',$lessonID)->get());

         return json_encode($activityDetail->toArray());
    }
    public function getActivityDetail($activityID)
    {
        //We have heirarchy like Activity->Questions->Answers. So we use three level of relationship to get answers from activities by using '.' with grand children
    	$activityDetail =  $this->activity
        ->with(['questions' => function($query) {
                    return $query->select('id', 'question', 'activity_id');
                }])
        ->with(['DrAstroNarrations' => function($query) {
                    return $query->select('id', 'narration_text', 'activity_id' ,'sort_order','narration_type')->where('narration_type','Dr.Astro');
                }])
        ->with(['Narrations2b' => function($query) {
                    return $query->select('id', 'narration_text', 'activity_id' ,'sort_order','narration_type')->where('narration_type','2b');
                }])
        ->with(['questions.answers' => function($query) {
                    return $query->select('id', 'question_id', 'answer_text','is_right');
                }])
        ->select('id','name','description','points_upon_completion','lesson_id','css_class','activity_type_class','starting_animation_video','ending_animation','starting_background','ending_background')->where('id',$activityID)->where('status','1')->get();

        if(isset($activityDetail[0]))
        {
            var_dump($activityDetail->toArray()); exit;
            return json_encode($activityDetail->toArray());

        }
        else
        {
               return response()->json(['status'=>'error', 'message' => 'Activity Not available']);             
        }
    }
}
