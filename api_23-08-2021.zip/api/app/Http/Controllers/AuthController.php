<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\ValidateRegisterRequest ;
use App\Http\Requests\ValidateLoginRequest ;
use Illuminate\Support\Facades\Auth;
use App\Models\StudentModel;
use App\Models\TeacherModel;
use DB;

class AuthController extends Controller
{
    public function __construct(User $user,StudentModel $StudentModel, TeacherModel $TeacherModel)
	{
	    $this->user = $user;
        $this->StudentModel = $StudentModel;
        $this->TeacherModel = $TeacherModel;
	    $this->middleware('auth:api', ['except' => ['/api/login','login','api/register','register']]);
	}
	public function register(ValidateRegisterRequest $request)
    {
        try{
       		$user_reg = $this->user->create($request->validated());
       		return response()->json(['status'=>'Success', 'message' => 'User Created Successfully. Please sign in to get token to perform Restfull requests.', 'userID'=>$user_reg->id ]);
       		//if token needed on registration then use commented code line below
       		 //return $this->login($request);
	    }catch(\Exception $e){
	        return $e->getMessage();
	    }
	        
	}
    public function login(ValidateLoginRequest $request)
    {
    	$credentials = request(['email', 'password']);
        if (! $token = auth()->attempt($credentials)) {
            return response()->json([
                'status' => 'error',
                'error' => "Ooops! These credientials do not match our records."], 401);
        }
        else
        {
            //now check if login is teacher or student, then return profile,
            //if login is administrator , simply response with token

            $checkUserInStudent = $this->StudentModel
            ->join('classes','students.class_id','=','classes.id')
            ->join('users','students.user_id','=','users.id')
            ->select('first_name','last_name','classes.name as class','email',DB::raw("'student' as type"))
            ->where('users.id','=',Auth::id())->get();

            $checkUserInTeacher = $this->TeacherModel
            ->join('classes','teachers.class_id','=','classes.id')
            ->join('users','teachers.user_id','=','users.id')
            ->select('first_name','last_name','classes.name as class','email',DB::raw("'teacher' as type"))
            ->where('users.id','=',Auth::id())->get();

            if(!$checkUserInStudent->isEmpty())
            {
                return $checkUserInStudent;
            }
            elseif(!$checkUserInTeacher->isEmpty())
            {
                return $checkUserInTeacher;   
            }
            else
            {
                return $this->respondWithToken($token);        
            }
            
        }
        
    }

     /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function respondWithToken($token)
    {
        return response()->json([
            'status' => 'success',
            'access_token' => $token,
            'token_type' => 'bearer',            
        ]);
    }
}
