<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserActivityPointsModel;
use App\Http\Requests\ValidateUserActivityScore ;

class UserActivityPointsController extends Controller
{
    public function __construct(UserActivityPointsModel $setpoints )
    {       
      $this->setpoints = $setpoints;
      $this->middleware('api');
    }
    
    public function setActivityPoints(ValidateUserActivityScore $request)
    {
        try{
        //saving activity points : time must be in seconds
        $clientAuthKey = $this->setpoints->create($request->validated());
        return response()->json(['status'=>'Success', 'message' => 'User Activity points saved successfully.']);
        }catch(\Exception $e){
                return response()->json(['status'=>'Error', 'message' => 'There is an error while saving Activity points. Please contact your administrator.']);
        }
    }
}
