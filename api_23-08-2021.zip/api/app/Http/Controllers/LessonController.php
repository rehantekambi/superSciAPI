<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LessonModel;

class LessonController extends Controller
{
     public function __construct(LessonModel $lesson)
    {
        $this->lesson = $lesson;
        $this->middleware('auth:api');
    }

    public function getLessons($roomID)
    {
        return $this->lesson->where('room_id',$roomID)->get(['name','description']);
    }
}
