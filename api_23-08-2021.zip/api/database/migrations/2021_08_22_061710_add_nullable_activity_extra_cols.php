<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddNullableActivityExtraCols extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('activities', function (Blueprint $table) {
            $table->dropColumn('activity_type_class');
            $table->dropColumn('starting_animation_video');
            $table->dropColumn('ending_animation');
            $table->dropColumn('starting_background');
            $table->dropColumn('ending_background');
        });

        Schema::table('activities', function($table)
        {
            $table->enum('activity_type_class', ['key-science-lingo', 'assessment', 'free-exploration','puzzle'])->default('key-science-lingo')->after('css_class')->nullable();
            $table->string('starting_animation_video')->after('activity_type_class')->nullable();
            $table->string('ending_animation')->after('starting_animation_video')->nullable();
            $table->string('starting_background')->after('ending_animation')->nullable();
            $table->string('ending_background')->after('starting_background')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        $table->enum('activity_type_class', ['key-science-lingo', 'assessment', 'free-exploration','puzzle'])->default('key-science-lingo')->after('css_class')->nullable(false)->change();
            $table->string('starting_animation_video')->after('activity_type_class')->nullable(false)->change();
            $table->string('ending_animation')->after('starting_animation_video')->nullable(false)->change();
            $table->string('starting_background')->after('ending_animation')->nullable(false)->change();
            $table->string('ending_background')->after('starting_background')->nullable(false)->change();
    }
}
